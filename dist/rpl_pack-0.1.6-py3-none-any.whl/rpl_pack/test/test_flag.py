import pytest

# from src.rpl_pack.flag import Brine
# 
# 
# def test_flag_brine_calculate_properties():
#     brine = Brine("user", "pass")
#     brine.calculate_properties()
#     sol = {
#         'Vw': array([1.51649484]),
#         'rho_w': array([1.0125224]),
#         'Kw': array([2.32855508]),
#         'Vb': array([1.57762052]),
#         'rho_b': array([1.04788464]),
#         'Kb': array([2.60806595])
#     }
#     assert brine.calculated_properties == sol