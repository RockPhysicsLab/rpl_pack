rpl\_pack.utils.scfstb\_m3m3
============================

.. currentmodule:: rpl_pack.utils

.. autofunction:: scfstb_m3m3