rpl\_pack.utils.NumpyEncoder
============================

.. currentmodule:: rpl_pack.utils

.. autoclass:: NumpyEncoder
   :members:
   :show-inheritance:
   :inherited-members:
   :special-members: __call__, __add__, __mul__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~NumpyEncoder.default
      ~NumpyEncoder.encode
      ~NumpyEncoder.iterencode
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NumpyEncoder.item_separator
      ~NumpyEncoder.key_separator
   
   