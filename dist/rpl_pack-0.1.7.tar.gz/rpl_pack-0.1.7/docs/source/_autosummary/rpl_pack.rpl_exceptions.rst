﻿rpl\_pack.rpl\_exceptions
=========================

.. automodule:: rpl_pack.rpl_exceptions

   
   
   

   
   
   

   
   
   

   
   
   .. rubric:: Exceptions

   .. autosummary::
      :toctree:
   
      RPLException
      RPLInvalidRequestException
      RPLServerException
      RPLUserCredentialsDeniedException
   
   



