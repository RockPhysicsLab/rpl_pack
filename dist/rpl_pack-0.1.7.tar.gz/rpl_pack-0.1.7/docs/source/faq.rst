FAQ
===

How do I do install rpl-pack?
-------------------------------------

Easy! Head over to the :doc:`quick_start` page and follow the detailed instructions.


Why do I keep getting RPLUserCredentialsDeniedException when I try to login?
----------------------------------------------------------------------------

This exception means that the server does not recognize your username or password.

Do you have an RPL account?

Please carefully look at the username and password you passed to one of the application
classes and see if there is a typo.