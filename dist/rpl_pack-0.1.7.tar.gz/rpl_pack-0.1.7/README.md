# Welcome To rpl-pack's Official Download Page

rpl-pack is a Python package for interacting with [RPL Web Service](https://rock-physics-lab.herokuapp.com/).

To get started using the RPL Web Service via rpl-pack head over to the [official documentation](https://rpl-pack.readthedocs.io/en/latest/index.html).
