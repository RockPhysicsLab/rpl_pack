rpl\_pack.test.test\_utils.test\_make\_array\_tuple\_to\_array
==============================================================

.. currentmodule:: rpl_pack.test.test_utils

.. autofunction:: test_make_array_tuple_to_array