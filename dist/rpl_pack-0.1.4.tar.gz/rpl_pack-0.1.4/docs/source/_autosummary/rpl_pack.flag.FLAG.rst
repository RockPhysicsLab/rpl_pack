rpl\_pack.flag.FLAG
===================

.. currentmodule:: rpl_pack.flag

.. autoclass:: FLAG
   :members:
   :show-inheritance:
   :inherited-members:
   :special-members: __call__, __add__, __mul__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
   
   

   
   
   