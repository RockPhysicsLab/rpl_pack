rpl\_pack.utils.timer
=====================

.. currentmodule:: rpl_pack.utils

.. autofunction:: timer