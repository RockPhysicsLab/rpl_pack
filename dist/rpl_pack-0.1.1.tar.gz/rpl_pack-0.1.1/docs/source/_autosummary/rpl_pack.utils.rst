﻿rpl\_pack.utils
===============

.. automodule:: rpl_pack.utils

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
      :nosignatures:
   
      decode_arrays
      encode_arrays
      m3m3_scfstb
      make_array
      scfstb_m3m3
      timer
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
      :nosignatures:
   
      NumpyEncoder
   
   

   
   
   



