rpl\_pack.test.test\_utils.test\_make\_array\_array\_to\_array
==============================================================

.. currentmodule:: rpl_pack.test.test_utils

.. autofunction:: test_make_array_array_to_array