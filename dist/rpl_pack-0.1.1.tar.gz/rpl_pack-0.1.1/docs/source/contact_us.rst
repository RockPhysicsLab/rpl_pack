Contact Us
==========

If something has gone wrong with your installation, you find a bug, or have another
technical difficulty that hasn't been addressed in the :doc:`faq` section, then please
contact us at `RPL Issues <https://rock-physics-lab.herokuapp.com/>`_.