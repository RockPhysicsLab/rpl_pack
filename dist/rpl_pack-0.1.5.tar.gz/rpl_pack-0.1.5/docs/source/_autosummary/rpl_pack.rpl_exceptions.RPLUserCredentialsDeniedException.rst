rpl\_pack.rpl\_exceptions.RPLUserCredentialsDeniedException
===========================================================

.. currentmodule:: rpl_pack.rpl_exceptions

.. autoexception:: RPLUserCredentialsDeniedException