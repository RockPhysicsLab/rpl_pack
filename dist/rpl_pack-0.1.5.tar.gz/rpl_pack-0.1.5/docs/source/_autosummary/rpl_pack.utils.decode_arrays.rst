rpl\_pack.utils.decode\_arrays
==============================

.. currentmodule:: rpl_pack.utils

.. autofunction:: decode_arrays