# Test RPL package to demo rpl-pack usage.

This is a simple example package.

Create an account through the demo RPL website as shown in the
RPL presentation and make a call to rpl_pack.FLAG.Brine.calculate_properties()
to demo how the API works!