rpl\_pack.utils.m3m3\_scfstb
============================

.. currentmodule:: rpl_pack.utils

.. autofunction:: m3m3_scfstb