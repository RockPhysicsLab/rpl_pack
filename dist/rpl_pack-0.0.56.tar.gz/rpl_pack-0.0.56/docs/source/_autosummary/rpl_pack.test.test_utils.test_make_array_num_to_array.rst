rpl\_pack.test.test\_utils.test\_make\_array\_num\_to\_array
============================================================

.. currentmodule:: rpl_pack.test.test_utils

.. autofunction:: test_make_array_num_to_array