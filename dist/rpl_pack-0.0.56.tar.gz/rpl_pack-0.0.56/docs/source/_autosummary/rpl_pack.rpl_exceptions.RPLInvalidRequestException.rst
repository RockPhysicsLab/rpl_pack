rpl\_pack.rpl\_exceptions.RPLInvalidRequestException
====================================================

.. currentmodule:: rpl_pack.rpl_exceptions

.. autoexception:: RPLInvalidRequestException