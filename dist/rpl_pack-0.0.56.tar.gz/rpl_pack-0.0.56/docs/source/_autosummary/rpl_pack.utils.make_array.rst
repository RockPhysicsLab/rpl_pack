rpl\_pack.utils.make\_array
===========================

.. currentmodule:: rpl_pack.utils

.. autofunction:: make_array