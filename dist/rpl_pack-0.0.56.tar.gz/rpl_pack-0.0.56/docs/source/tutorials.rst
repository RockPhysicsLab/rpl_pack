Tutorials
=========

For more information on Python itself, see `their web site <https://python.org/>`_.


An Introduction
---------------

The rpl-pack package contains modules for separate progam interfaces that need
to be logged into.

Here is a short example of how we can calculate properties of brine, and call 
a convienient plot method on the Brine application instance to visualize some data.

.. code-block:: python

    import numpy as np
    
    from rpl_pack.flag import Brine

    # Instantiate application interface
    brine = Brine('username', 'password')

    # Make computation request to RPL server
    brine_props = brine.calculate_properties()

    # Print brine properties
    print(brine_props)

    # Plot brine properties
    brine.plot()

